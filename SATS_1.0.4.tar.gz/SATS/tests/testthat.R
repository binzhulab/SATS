library(testthat)
library(SATS)

test_check("SATS")
